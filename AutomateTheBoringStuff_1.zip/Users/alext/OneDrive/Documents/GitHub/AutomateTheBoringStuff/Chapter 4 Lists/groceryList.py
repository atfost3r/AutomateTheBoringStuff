groceryList = []

def printList(food):
    for 