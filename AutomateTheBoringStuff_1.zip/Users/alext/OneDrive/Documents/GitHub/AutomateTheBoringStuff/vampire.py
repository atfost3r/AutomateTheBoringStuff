if name == 'Alice':
    print('Hi, Alice.')
elif age:
        